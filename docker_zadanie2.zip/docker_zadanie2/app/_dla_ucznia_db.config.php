<?php 

return [
    'DB_HOST' => '___UZUPELNIJ____', //czesc zdania do uzupelnienia
    'DB_USER' => 'db_user',
    'DB_PASS' => 'db_pass',
    'DB_NAME' => 'db_name'
];
